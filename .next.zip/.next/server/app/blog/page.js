(()=>{var e={};e.id=404,e.ids=[404,669,989],e.modules={2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},5315:e=>{"use strict";e.exports=require("path")},7360:e=>{"use strict";e.exports=require("url")},1244:(e,t,i)=>{"use strict";i.r(t),i.d(t,{GlobalError:()=>r.a,__next_app__:()=>u,originalPathname:()=>p,pages:()=>d,routeModule:()=>m,tree:()=>c}),i(1918),i(8869),i(5866);var a=i(3191),n=i(8716),o=i(7922),r=i.n(o),s=i(5231),l={};for(let e in s)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>s[e]);i.d(t,l);let c=["",{children:["blog",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(i.bind(i,1918)),"/Users/safi/Desktop/Sayed-Safi-Portfolio/app/blog/page.tsx"]}]},{metadata:{icon:[],apple:[],openGraph:[async e=>(await Promise.resolve().then(i.bind(i,5193))).default(e)],twitter:[],manifest:"/manifest.webmanifest"}}]},{layout:[()=>Promise.resolve().then(i.bind(i,8869)),"/Users/safi/Desktop/Sayed-Safi-Portfolio/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(i.t.bind(i,5866,23)),"next/dist/client/components/not-found-error"],metadata:{icon:[],apple:[],openGraph:[async e=>(await Promise.resolve().then(i.bind(i,5193))).default(e)],twitter:[],manifest:"/manifest.webmanifest"}}],d=["/Users/safi/Desktop/Sayed-Safi-Portfolio/app/blog/page.tsx"],p="/blog/page",u={require:i,loadChunk:()=>Promise.resolve()},m=new a.AppPageRouteModule({definition:{kind:n.x.APP_PAGE,page:"/blog/page",pathname:"/blog",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},9533:(e,t,i)=>{Promise.resolve().then(i.bind(i,6010))},6010:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>g});var a=i(326),n=i(7577),o=i(912),r=i(6968),s=i(6561),l=i(9067),c=i(4896),d=i(5992),p=i(1669),u=i(725),m=i(4989);function g(){let[e,t]=(0,n.useState)(!0);return(0,a.jsxs)(a.Fragment,{children:[e&&a.jsx(d.Z,{}),(0,a.jsxs)(o.E.main,{initial:{opacity:0},animate:{opacity:1},transition:{duration:.4},className:"min-h-screen bg-white dark:bg-gray-900 transition-colors duration-500 relative",children:[a.jsx(s.Z,{}),a.jsx(l.Z,{}),a.jsx(c.Z,{}),a.jsx(m.default,{}),a.jsx(r.Z,{}),a.jsx(p.default,{}),a.jsx(u.default,{})]})]})}},1669:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>u});var a=i(326),n=i(912),o=i(8326),r=i(7577),s=i(434),l=i(7358),c=i(8998),d=i(4230);let p=[{slug:"building-modern-web-applications-with-nextjs-14",title:"Building Modern Web Applications with Next.js 14: A Complete Guide",excerpt:"Learn how to leverage the latest features of Next.js 14 including Server Components, App Router, and improved performance optimizations to build fast, scalable web applications.",content:`
# Building Modern Web Applications with Next.js 14: A Complete Guide

Next.js 14 represents a significant leap forward in React framework development, introducing powerful features that make building modern web applications more efficient and performant. In this comprehensive guide, we'll explore the key features and best practices for building production-ready applications.

## Introduction to Next.js 14

Next.js 14 brings several groundbreaking features that enhance both developer experience and application performance. The framework continues to evolve, making it the go-to choice for building React applications at scale.

## Key Features

### Server Components

Server Components are one of the most significant additions in Next.js 14. They allow you to render components on the server, reducing the JavaScript bundle size sent to the client and improving initial page load times.

\`\`\`tsx
// app/components/ServerComponent.tsx
export default async function ServerComponent() {
  const data = await fetch('https://api.example.com/data')
  const result = await data.json()
  
  return (
    <div>
      <h1>{result.title}</h1>
      <p>{result.description}</p>
    </div>
  )
}
\`\`\`

### App Router

The App Router provides a more intuitive file-based routing system with support for layouts, loading states, and error boundaries. It's built on React Server Components, enabling better performance and developer experience.

### Improved Performance

Next.js 14 includes several performance optimizations:
- Automatic code splitting
- Image optimization with next/image
- Font optimization
- Built-in CSS support

## Best Practices

1. **Use Server Components by Default**: Start with Server Components and only use Client Components when you need interactivity.

2. **Optimize Images**: Always use the next/image component for automatic optimization.

3. **Implement Proper Caching**: Use Next.js caching strategies to improve performance.

4. **Code Splitting**: Leverage dynamic imports for code splitting.

## Conclusion

Next.js 14 provides developers with powerful tools to build modern, performant web applications. By understanding and implementing these features correctly, you can create applications that are both fast and maintainable.
    `,date:"2024-01-15",readTime:"8 min read",category:"Web Development",image:"/api/placeholder/1200/630",link:"/blog/building-modern-web-applications-with-nextjs-14",tags:["Next.js","React","Web Development","Server Components","App Router"],author:{name:"Sayed Safi",bio:"Full-Stack Web Developer specializing in modern web technologies",image:"/api/placeholder/100/100"}},{slug:"mastering-typescript-for-better-code-quality",title:"Mastering TypeScript for Better Code Quality: Advanced Patterns and Best Practices",excerpt:"Discover advanced TypeScript patterns, type safety techniques, and best practices that will help you write more maintainable, scalable, and error-free code in your projects.",content:`
# Mastering TypeScript for Better Code Quality: Advanced Patterns and Best Practices

TypeScript has become the standard for building large-scale JavaScript applications. This guide covers advanced patterns and best practices to help you write better, more maintainable code.

## Why TypeScript Matters

TypeScript provides static type checking, which helps catch errors at compile time rather than runtime. This leads to more reliable code and better developer experience.

## Advanced Type Patterns

### Utility Types

TypeScript provides several utility types that can help you manipulate types:

\`\`\`typescript
// Partial makes all properties optional
type PartialUser = Partial<User>

// Pick selects specific properties
type UserEmail = Pick<User, 'email' | 'name'>

// Omit removes specific properties
type UserWithoutId = Omit<User, 'id'>
\`\`\`

### Generic Constraints

Generics allow you to create reusable components:

\`\`\`typescript
function getProperty<T, K extends keyof T>(obj: T, key: K): T[K] {
  return obj[key]
}
\`\`\`

## Best Practices

1. **Strict Mode**: Always enable strict mode in tsconfig.json
2. **Avoid Any**: Use unknown instead of any when the type is truly unknown
3. **Type Guards**: Use type guards to narrow types safely
4. **Interface vs Type**: Use interfaces for object shapes, types for unions and intersections

## Conclusion

Mastering TypeScript requires understanding both its type system and best practices. By following these patterns, you can write more maintainable and type-safe code.
    `,date:"2024-01-10",readTime:"10 min read",category:"Programming",image:"/api/placeholder/1200/630",link:"/blog/mastering-typescript-for-better-code-quality",tags:["TypeScript","Programming","Best Practices","Type Safety","Code Quality"],author:{name:"Sayed Safi",bio:"Full-Stack Web Developer specializing in modern web technologies",image:"/api/placeholder/100/100"}},{slug:"future-of-ecommerce-medusajs-deep-dive",title:"The Future of E-commerce: A Deep Dive into MedusaJS Architecture",excerpt:"Explore how MedusaJS is revolutionizing e-commerce development with its flexible, headless architecture, powerful customization options, and modern tech stack.",content:`
# The Future of E-commerce: A Deep Dive into MedusaJS Architecture

MedusaJS is an open-source, headless e-commerce platform that provides developers with the flexibility to build custom e-commerce solutions. This article explores its architecture and capabilities.

## What is MedusaJS?

MedusaJS is a Node.js-based e-commerce framework that provides a robust backend for building modern e-commerce applications. It's designed to be headless, meaning the frontend and backend are decoupled.

## Key Features

### Headless Architecture

MedusaJS follows a headless architecture, allowing you to:
- Build custom frontends with any framework
- Integrate with multiple sales channels
- Maintain flexibility in design and user experience

### Powerful Admin Dashboard

The admin dashboard provides comprehensive tools for managing:
- Products and inventory
- Orders and customers
- Payment and shipping configurations
- Custom plugins and integrations

### Extensibility

MedusaJS is highly extensible through:
- Custom plugins
- API extensions
- Webhook integrations
- Custom workflows

## Implementation Example

\`\`\`typescript
// Creating a custom service in MedusaJS
import { BaseService } from "medusa-interfaces"

class CustomProductService extends BaseService {
  async getFeaturedProducts() {
    return await this.productRepository.find({
      where: { featured: true }
    })
  }
}
\`\`\`

## Best Practices

1. **Use Plugins**: Leverage the plugin system for custom functionality
2. **Optimize Queries**: Use proper indexing and query optimization
3. **Implement Caching**: Cache frequently accessed data
4. **Security**: Always validate and sanitize user inputs

## Conclusion

MedusaJS provides a powerful foundation for building modern e-commerce applications. Its headless architecture and extensibility make it an excellent choice for developers who need flexibility and control.
    `,date:"2024-01-05",readTime:"12 min read",category:"E-commerce",image:"/api/placeholder/1200/630",link:"/blog/future-of-ecommerce-medusajs-deep-dive",tags:["MedusaJS","E-commerce","Backend","Headless Commerce","Node.js"],author:{name:"Sayed Safi",bio:"Full-Stack Web Developer specializing in modern web technologies",image:"/api/placeholder/100/100"}},{slug:"optimizing-react-performance-complete-guide",title:"Optimizing React Performance: A Complete Guide to Faster Applications",excerpt:"Comprehensive guide on React performance optimization techniques including memoization, code splitting, lazy loading, and advanced rendering strategies.",content:`
# Optimizing React Performance: A Complete Guide to Faster Applications

React performance optimization is crucial for building fast, responsive applications. This guide covers essential techniques and best practices.

## Understanding React Rendering

React re-renders components when:
- State changes
- Props change
- Parent component re-renders
- Context values change

## Performance Optimization Techniques

### 1. React.memo

Use React.memo to prevent unnecessary re-renders:

\`\`\`tsx
const ExpensiveComponent = React.memo(({ data }) => {
  return <div>{/* expensive rendering */}</div>
}, (prevProps, nextProps) => {
  return prevProps.data.id === nextProps.data.id
})
\`\`\`

### 2. useMemo and useCallback

Memoize expensive calculations and functions:

\`\`\`tsx
const expensiveValue = useMemo(() => {
  return computeExpensiveValue(a, b)
}, [a, b])

const handleClick = useCallback(() => {
  doSomething(id)
}, [id])
\`\`\`

### 3. Code Splitting

Split your code to reduce initial bundle size:

\`\`\`tsx
const LazyComponent = React.lazy(() => import('./LazyComponent'))

function App() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <LazyComponent />
    </Suspense>
  )
}
\`\`\`

### 4. Virtualization

Use virtualization for long lists:

\`\`\`tsx
import { FixedSizeList } from 'react-window'

function VirtualizedList({ items }) {
  return (
    <FixedSizeList
      height={600}
      itemCount={items.length}
      itemSize={50}
      width="100%"
    >
      {({ index, style }) => (
        <div style={style}>{items[index]}</div>
      )}
    </FixedSizeList>
  )
}
\`\`\`

## Best Practices

1. **Profile First**: Use React DevTools Profiler to identify bottlenecks
2. **Avoid Premature Optimization**: Optimize only when needed
3. **Monitor Bundle Size**: Keep track of your bundle size
4. **Use Production Builds**: Always test with production builds

## Conclusion

React performance optimization requires understanding rendering behavior and applying appropriate techniques. Start with profiling, then apply optimizations where they matter most.
    `,date:"2023-12-28",readTime:"15 min read",category:"React",image:"/api/placeholder/1200/630",link:"/blog/optimizing-react-performance-complete-guide",tags:["React","Performance","Optimization","Memoization","Code Splitting"],author:{name:"Sayed Safi",bio:"Full-Stack Web Developer specializing in modern web technologies",image:"/api/placeholder/100/100"}},{slug:"mongodb-best-practices-modern-applications",title:"MongoDB Best Practices for Modern Web Applications",excerpt:"Learn essential MongoDB best practices including schema design, indexing strategies, query optimization, and security measures for building scalable applications.",content:`
# MongoDB Best Practices for Modern Web Applications

MongoDB is a powerful NoSQL database that's widely used in modern web applications. This guide covers essential best practices for working with MongoDB effectively.

## Schema Design

### Embedding vs Referencing

Choose between embedding and referencing based on your use case:

**Embedding** is good for:
- Small, related data
- Data that's frequently accessed together
- One-to-many relationships where the "many" side is small

**Referencing** is good for:
- Large documents
- Frequently updated data
- Many-to-many relationships

\`\`\`javascript
// Embedding example
{
  _id: ObjectId("..."),
  name: "John Doe",
  address: {
    street: "123 Main St",
    city: "New York"
  }
}

// Referencing example
{
  _id: ObjectId("..."),
  name: "John Doe",
  addressId: ObjectId("...")
}
\`\`\`

## Indexing Strategies

Proper indexing is crucial for query performance:

\`\`\`javascript
// Create indexes
db.users.createIndex({ email: 1 })
db.users.createIndex({ name: 1, email: 1 }) // Compound index

// Use explain to analyze queries
db.users.find({ email: "user@example.com" }).explain("executionStats")
\`\`\`

## Query Optimization

1. **Use Projection**: Only fetch fields you need
2. **Limit Results**: Use limit() to restrict result size
3. **Use Aggregation**: For complex queries, use aggregation pipeline
4. **Avoid Large Skips**: Use cursor-based pagination instead of skip()

\`\`\`javascript
// Good: Using projection
db.users.find({}, { name: 1, email: 1 })

// Good: Cursor-based pagination
db.users.find({ _id: { $gt: lastId } }).limit(20)

// Avoid: Large skips
db.users.find().skip(10000).limit(20) // Inefficient
\`\`\`

## Security Best Practices

1. **Authentication**: Always enable authentication
2. **Authorization**: Use role-based access control
3. **Encryption**: Encrypt sensitive data
4. **Input Validation**: Validate all inputs
5. **Regular Updates**: Keep MongoDB updated

## Performance Tips

1. **Connection Pooling**: Use connection pooling
2. **Read Preferences**: Configure read preferences for replica sets
3. **Write Concerns**: Set appropriate write concerns
4. **Monitoring**: Use MongoDB Atlas or monitoring tools

## Conclusion

Following MongoDB best practices helps you build scalable, performant applications. Focus on proper schema design, indexing, and query optimization for best results.
    `,date:"2023-12-20",readTime:"11 min read",category:"Database",image:"/api/placeholder/1200/630",link:"/blog/mongodb-best-practices-modern-applications",tags:["MongoDB","Database","NoSQL","Backend","Best Practices"],author:{name:"Sayed Safi",bio:"Full-Stack Web Developer specializing in modern web technologies",image:"/api/placeholder/100/100"}},{slug:"wordpress-customization-advanced-techniques",title:"WordPress Customization: Advanced Techniques for Developers",excerpt:"Master advanced WordPress customization techniques including custom post types, theme development, plugin creation, and performance optimization for professional websites.",content:`
# WordPress Customization: Advanced Techniques for Developers

WordPress remains one of the most popular CMS platforms. This guide covers advanced customization techniques for developers who want to build professional, custom WordPress solutions.

## Custom Post Types

Create custom post types for specialized content:

\`\`\`php
function register_custom_post_type() {
  register_post_type('portfolio', array(
    'labels' => array(
      'name' => 'Portfolio',
      'singular_name' => 'Portfolio Item'
    ),
    'public' => true,
    'has_archive' => true,
    'supports' => array('title', 'editor', 'thumbnail'),
    'menu_icon' => 'dashicons-portfolio'
  ));
}
add_action('init', 'register_custom_post_type');
\`\`\`

## Custom Taxonomies

Add custom taxonomies to organize content:

\`\`\`php
function register_custom_taxonomy() {
  register_taxonomy('project_category', 'portfolio', array(
    'labels' => array(
      'name' => 'Project Categories',
      'singular_name' => 'Project Category'
    ),
    'hierarchical' => true,
    'public' => true
  ));
}
add_action('init', 'register_custom_taxonomy');
\`\`\`

## Theme Development

### Creating a Child Theme

Always use child themes to preserve customizations:

\`\`\`php
// style.css
/*
Theme Name: My Child Theme
Template: parent-theme
*/

@import url("../parent-theme/style.css");
\`\`\`

### Custom Templates

Create custom page templates:

\`\`\`php
<?php
/*
Template Name: Custom Landing Page
*/
get_header();
?>
<div class="custom-landing">
  <?php while (have_posts()) : the_post(); ?>
    <h1><?php the_title(); ?></h1>
    <?php the_content(); ?>
  <?php endwhile; ?>
</div>
<?php get_footer(); ?>
\`\`\`

## Plugin Development

### Creating a Basic Plugin

\`\`\`php
<?php
/**
 * Plugin Name: My Custom Plugin
 * Description: A custom plugin for specific functionality
 * Version: 1.0.0
 */

function my_custom_function() {
  // Plugin functionality
}
add_action('init', 'my_custom_function');
\`\`\`

## Performance Optimization

1. **Caching**: Implement object caching
2. **Database Optimization**: Optimize database queries
3. **Image Optimization**: Compress and optimize images
4. **Minification**: Minify CSS and JavaScript
5. **CDN**: Use a CDN for static assets

## Security Best Practices

1. **Keep WordPress Updated**: Always use the latest version
2. **Use Strong Passwords**: Enforce strong password policies
3. **Limit Login Attempts**: Prevent brute force attacks
4. **Use Security Plugins**: Implement security measures
5. **Regular Backups**: Maintain regular backups

## Conclusion

WordPress customization requires understanding its architecture and best practices. By following these techniques, you can build powerful, custom WordPress solutions that meet specific business needs.
    `,date:"2023-12-15",readTime:"13 min read",category:"WordPress",image:"/api/placeholder/1200/630",link:"/blog/wordpress-customization-advanced-techniques",tags:["WordPress","CMS","PHP","Theme Development","Plugin Development"],author:{name:"Sayed Safi",bio:"Full-Stack Web Developer specializing in modern web technologies",image:"/api/placeholder/100/100"}}];function u(){let e=(0,r.useRef)(null),t=(0,o.Y)(e,{once:!0,margin:"-100px"}),i=e=>new Date(e).toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"});return a.jsx("section",{id:"blog",ref:e,className:"py-20 md:py-32 pt-24 md:pt-28 bg-gray-50 dark:bg-gray-800/50",children:(0,a.jsxs)("div",{className:"container mx-auto px-4 sm:px-6 lg:px-8",children:[(0,a.jsxs)(n.E.div,{initial:{opacity:0,y:20},animate:t?{opacity:1,y:0}:{},transition:{duration:.5},className:"text-center mb-16",children:[a.jsx(n.E.span,{className:"inline-block text-sm text-blue-600 dark:text-blue-400 font-semibold px-4 py-2 bg-blue-100 dark:bg-blue-900/30 rounded-full mb-4",initial:{opacity:0,scale:.8},animate:t?{opacity:1,scale:1}:{},transition:{delay:.2},children:"\uD83D\uDCDD Latest Articles"}),a.jsx("h2",{className:"text-4xl md:text-5xl font-bold mb-4 text-gray-900 dark:text-white",children:"My Blog"}),a.jsx("p",{className:"text-sm md:text-base text-gray-600 dark:text-gray-400 max-w-2xl mx-auto",children:"Thoughts, tutorials, and insights about web development and technology"})]}),a.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8",children:p.slice(0,6).map((e,t)=>(0,a.jsxs)(n.E.article,{initial:{opacity:0,y:100,rotateX:-15,scale:.9},whileInView:{opacity:1,y:0,rotateX:0,scale:1},transition:{delay:.15*t,duration:.8,type:"spring",stiffness:100,damping:15},viewport:{once:!0,margin:"-50px"},whileHover:{y:-15,rotateY:8,rotateX:5,scale:1.02,z:50},className:"group relative bg-white dark:bg-gray-900 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all perspective-1000",children:[(0,a.jsxs)("div",{className:"relative h-48 bg-gradient-to-br from-blue-500 to-purple-600 overflow-hidden",children:[a.jsx(n.E.div,{className:"absolute inset-0 bg-gradient-to-br from-blue-600/80 to-purple-600/80 group-hover:from-blue-500/90 group-hover:to-purple-500/90 transition-all",whileHover:{scale:1.1}}),a.jsx(n.E.div,{className:"absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"}),a.jsx("div",{className:"absolute inset-0 flex items-center justify-center",children:a.jsx(n.E.span,{className:"text-white text-xl font-bold",animate:{opacity:[.5,1,.5]},transition:{duration:3,repeat:1/0},children:e.category})}),a.jsx(n.E.div,{className:"absolute top-4 left-4 px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full",initial:{opacity:0,scale:0},whileInView:{opacity:1,scale:1},transition:{delay:.15*t+.3},children:a.jsx("span",{className:"text-white text-xs font-semibold",children:e.category})})]}),(0,a.jsxs)("div",{className:"p-6",children:[(0,a.jsxs)(n.E.div,{className:"flex items-center gap-4 text-xs text-gray-500 dark:text-gray-400 mb-3",initial:{opacity:0},whileInView:{opacity:1},transition:{delay:.15*t+.4},children:[(0,a.jsxs)("div",{className:"flex items-center gap-1",children:[a.jsx(l.Z,{size:14}),a.jsx("span",{children:i(e.date)})]}),(0,a.jsxs)("div",{className:"flex items-center gap-1",children:[a.jsx(c.Z,{size:14}),a.jsx("span",{children:e.readTime})]})]}),a.jsx(n.E.h3,{className:"text-xl font-bold mb-3 text-gray-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors",initial:{opacity:0,x:-20},whileInView:{opacity:1,x:0},transition:{delay:.15*t+.5},children:e.title}),a.jsx(n.E.p,{className:"text-sm text-gray-600 dark:text-gray-400 mb-4 leading-relaxed line-clamp-3",initial:{opacity:0},whileInView:{opacity:1},transition:{delay:.15*t+.6},children:e.excerpt}),a.jsx(n.E.div,{className:"flex flex-wrap gap-2 mb-4",initial:{opacity:0},whileInView:{opacity:1},transition:{delay:.15*t+.7},children:e.tags.map((e,i)=>a.jsx(n.E.span,{className:"px-2 py-1 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-full text-xs font-medium",initial:{opacity:0,scale:0},whileInView:{opacity:1,scale:1},whileHover:{scale:1.1,y:-2},transition:{delay:.15*t+.7+.1*i,type:"spring"},children:e},e))}),(0,a.jsxs)(s.default,{href:`/blog/${e.slug}`,className:"inline-flex items-center gap-2 text-blue-600 dark:text-blue-400 font-semibold hover:text-blue-700 dark:hover:text-blue-300 transition-colors group/link",children:[a.jsx(n.E.span,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},whileHover:{x:5},transition:{delay:.15*t+.8},children:"Read More"}),a.jsx(n.E.div,{whileHover:{x:5},transition:{type:"spring",stiffness:400},children:a.jsx(d.Z,{size:18})}),a.jsx(n.E.span,{className:"absolute bottom-0 left-0 w-0 h-0.5 bg-blue-600 group-hover/link:w-full transition-all"})]})]}),a.jsx(n.E.div,{className:"absolute inset-0 bg-gradient-to-r from-blue-500/0 via-purple-500/0 to-pink-500/0 group-hover:from-blue-500/10 group-hover:via-purple-500/10 group-hover:to-pink-500/10 transition-all pointer-events-none rounded-2xl",initial:!1})]},e.title))}),p.length>6&&a.jsx(n.E.div,{className:"text-center mt-12",initial:{opacity:0,y:20},animate:t?{opacity:1,y:0}:{},transition:{delay:.8},children:(0,a.jsxs)(n.E.a,{href:"#blog",className:"inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full font-semibold shadow-lg hover:shadow-xl transition-all",whileHover:{scale:1.05,y:-2},whileTap:{scale:.95},children:[a.jsx("span",{children:"View All Posts"}),a.jsx(d.Z,{size:20})]})})]})})}},4989:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>r});var a=i(326),n=i(912),o=i(7577);function r(){let[e,t]=(0,o.useState)(!1);return e?a.jsx("div",{className:"fixed inset-0 pointer-events-none overflow-hidden z-0",children:[{size:80,x:10,y:20,duration:20,delay:0,color:"blue"},{size:100,x:80,y:40,duration:25,delay:5,color:"purple"},{size:70,x:50,y:70,duration:22,delay:2,color:"pink"},{size:90,x:20,y:10,duration:28,delay:7,color:"cyan"}].map((e,t)=>a.jsx(n.E.div,{className:"absolute rounded-full opacity-20 blur-2xl",style:{width:e.size,height:e.size,left:`${e.x}%`,top:`${e.y}%`,background:`radial-gradient(circle, ${{blue:"rgba(59, 130, 246, 0.2)",purple:"rgba(139, 92, 246, 0.2)",pink:"rgba(236, 72, 153, 0.2)"}[e.color]}, ${{blue:"rgba(139, 92, 246, 0.2)",purple:"rgba(236, 72, 153, 0.2)",pink:"rgba(59, 130, 246, 0.2)"}[e.color]})`},animate:{scale:[1,1.3,1],rotate:[0,180,360],x:[0,30,0],y:[0,-30,0]},transition:{scale:{duration:e.duration/2,repeat:1/0,ease:"easeInOut"},rotate:{duration:2*e.duration,repeat:1/0,ease:"linear"},x:{duration:e.duration,repeat:1/0,ease:"easeInOut",delay:e.delay},y:{duration:e.duration,repeat:1/0,ease:"easeInOut",delay:e.delay}}},t))}):a.jsx("div",{className:"fixed inset-0 pointer-events-none overflow-hidden z-0",suppressHydrationWarning:!0})}},4230:(e,t,i)=>{"use strict";i.d(t,{Z:()=>a});let a=(0,i(6557).Z)("ArrowRight",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]])},7358:(e,t,i)=>{"use strict";i.d(t,{Z:()=>a});let a=(0,i(6557).Z)("Calendar",[["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",ry:"2",key:"eu3xkr"}],["line",{x1:"16",x2:"16",y1:"2",y2:"6",key:"m3sa8f"}],["line",{x1:"8",x2:"8",y1:"2",y2:"6",key:"18kwsl"}],["line",{x1:"3",x2:"21",y1:"10",y2:"10",key:"xt86sb"}]])},8998:(e,t,i)=>{"use strict";i.d(t,{Z:()=>a});let a=(0,i(6557).Z)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},1918:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>a});let a=(0,i(8570).createProxy)(String.raw`/Users/safi/Desktop/Sayed-Safi-Portfolio/app/blog/page.tsx#default`)},8326:(e,t,i)=>{"use strict";i.d(t,{Y:()=>r});var a=i(7577),n=i(9138);let o={some:0,all:1};function r(e,{root:t,margin:i,amount:r,once:s=!1}={}){let[l,c]=(0,a.useState)(!1);return(0,a.useEffect)(()=>{if(!e.current||s&&l)return;let a={root:t&&t.current||void 0,margin:i,amount:r};return function(e,t,{root:i,margin:a,amount:r="some"}={}){let s=(0,n.I)(e),l=new WeakMap,c=new IntersectionObserver(e=>{e.forEach(e=>{let i=l.get(e.target);if(!!i!==e.isIntersecting){if(e.isIntersecting){let i=t(e);"function"==typeof i?l.set(e.target,i):c.unobserve(e.target)}else i&&(i(e),l.delete(e.target))}})},{root:i,rootMargin:a,threshold:"number"==typeof r?r:o[r]});return s.forEach(e=>c.observe(e)),()=>c.disconnect()}(e.current,()=>(c(!0),s?void 0:()=>c(!1)),a)},[t,e,i,s,r]),l}}};var t=require("../../webpack-runtime.js");t.C(e);var i=e=>t(t.s=e),a=t.X(0,[948,401,339,355,958,725],()=>i(1244));module.exports=a})();